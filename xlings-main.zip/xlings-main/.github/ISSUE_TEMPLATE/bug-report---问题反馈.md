---
name: Bug report | 问题反馈
about: Create a report to help us improve
title: ''
labels: bug
assignees: ''

---

### Background | 背景

### Describe | 问题描述

### Desktop | 环境

### To Reproduce | 复现步骤

### Expection | 预期结果

### Solution by you | 已尝试的方案

### Additional context | 额外补充
