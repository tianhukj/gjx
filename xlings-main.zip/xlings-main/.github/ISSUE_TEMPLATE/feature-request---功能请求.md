---
name: Feature request | 功能请求
about: Suggest an idea for this project
title: "[features]:"
labels: feature | 功能
assignees: ''

---

### Features Describe | 功能描述

###  Usage Scenario | 需求背景/使用场景

###  Maybe Solutions | 可能的实现方案 - (if you are developer)

### Additional context | 额外补充
