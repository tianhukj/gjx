# drepo

xlings的包(项目)管理工具

## 添加项目到drepo

> 参考模板文件[d2x.repo](d2x.repo)