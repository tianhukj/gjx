#include <iostream>

#include "exercises/cpplings.hpp"

int mian() {
    d2cpp::Hello hello
    return 0;
}
