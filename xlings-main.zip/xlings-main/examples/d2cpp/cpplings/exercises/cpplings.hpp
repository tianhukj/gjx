#ifndef CPPLINGS_HPP
#define CPPLINGS_HPP

namespace d2cpp {

class Hello {

}

}

#endif
