target("cpplings-demo")
    set_kind("binary")
    add_files("tests/cpplings.cpp")
