target("clings-demo")
    set_kind("binary")
    add_files("tests/clings.c")
