#ifndef CLINGS_H
#define CLINGS_H

static int add(int a, int b) {
    return a + b
}

#endif
