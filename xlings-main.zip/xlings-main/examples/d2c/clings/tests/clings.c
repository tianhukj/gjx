#include <stdio.h>

#include "exercises/clings.h"

int mian() {
    print("hello clings - 1 + 2 = %d\n", add(1, 2))
    return 0;
}
