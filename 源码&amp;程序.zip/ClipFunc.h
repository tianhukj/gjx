#ifndef CLIPDEF
#include "ClipDef.h"
#endif
#ifndef CLIPFUNC
#define CLIPFUNC
//class basicFunc{
	//��һЩ�����õ���εĺ����� �Թ��̳�ʹ�ü򻯴��� Ŀǰ������ʱԤ��
//};
void ColorOut(int ForgC,int BackC){
	WORD wColor=((BackC&0x0F)<<4)+(ForgC&0x0F);
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),wColor);
}
void ClearConsole()
{
    HANDLE hStdout=GetStdHandle(STD_OUTPUT_HANDLE);
    COORD topLeft={0,0};
    DWORD written;
	CONSOLE_SCREEN_BUFFER_INFO csbi;
    GetConsoleScreenBufferInfo(hStdout,&csbi);
	FillConsoleOutputCharacter(hStdout,' ',csbi.dwSize.X*csbi.dwSize.Y,topLeft,&written);
	FillConsoleOutputAttribute(hStdout,csbi.wAttributes,csbi.dwSize.X*csbi.dwSize.Y,topLeft,&written);
    SetConsoleCursorPosition(hStdout,topLeft);
}
string int2string(int num){
    string result;
	bool isNegative=false;
	if(num<0){
        isNegative=true;
        num=-num;
    }
	if(num==0){
        result="0";
    }else{
        while(num!=0){
            char digit='0'+num%10;
            result=digit+result;
            num/=10;
        }
    }
	if(isNegative){
        result='-'+result;
    }
	return result;
}
class Cahce{
	public:
		vector<vector<string> >dCahce;
		vector<string>fCahce;
		int putin(vector<string>&vec){
			dCahce.push_back(vec);
			return dCahce.size()-1;
		}
};
class Func{
	public:
		vector<vector<string> >funcMem;
		vector<string>funcName;
		void createFunc(vector<string>&nr,string name){
			funcMem.push_back(nr);
			funcName.push_back(name);
		}
		int find(string name){
			if(funcName.size()<1)return -1;
			for(long i=0;i<=funcName.size();++i){
				if(funcName[i]==name)return i;
			}
			return -1;
		}
		string func_valuereplace(string raw,vector<string>&value_nr){
			int js=0;
			while(raw.find('%')!=string::npos){
				++js;
				int start=raw.find('%')+1;
				int end=raw.find('%',start);
				if(end==string::npos){
					return ERROR;
				}
				string placeholder=raw.substr(start,end-start);
				string value=value_nr.size()>=atoi(placeholder.c_str())?value_nr[atoi(placeholder.c_str())]:"NULL";
				if(value.c_str()==ERROR){
					return ERROR;
				}
				raw.replace(start-1,end-start+2,value);
			}
			return raw;
		}
};
class UserInput{
	public:
		vector<string>value;
		string cmd;
		vector<string>_switch;
		int cut(string input){
			int ERROR_LEVEL=0;//���ش���-����������ָ��=0,�޳ɶ�С����=1,����Ϊ��=2,�޿���=3,����Ϊ��=-1
			if(input!=""){
				if(input.find('(')!=string::npos&&input.find(')')!=string::npos){
					cmd=input.substr(0,input.find('('));
					if(input.find('(')+1!=input.find(')')){
						int js=0;
						string value_raw=input.substr(input.find('('),input.size()-input.find('(')-(input.size()-input.find(')')));
						while(value_raw.find(',')!=string::npos){
							++js;
							if(js>1)value.push_back(value_raw.substr(0,value_raw.find(',')));else{
								string tmp=value_raw.substr(0,value_raw.find(','));
								tmp.erase(0,1);
								value.push_back(tmp);
							}
							value_raw.erase(0,value_raw.find(',')+1);
						}
						if(value_raw[0]=='(')value_raw.erase(0,1);
						value.push_back(value_raw);
					}else ERROR_LEVEL=2;
					if(input.find('/')!=string::npos){
						string _switch_raw=input.substr(input.find(')'),input.size()-input.find(')'));
						while(_switch_raw.find('/')!=string::npos){
							_switch.push_back(_switch_raw.substr(_switch_raw.find('/')+1,_switch_raw.find('/',_switch_raw.find('/')+1)-_switch_raw.find('/')));
							_switch_raw.erase(0,2);
						}
					}else ERROR_LEVEL=3;
				}else{
					while(input.find('(')!=string::npos||input.find(')')!=string::npos){
						if(input.find('(')!=string::npos)input.erase(input.find('(')-1,1);
						if(input.find(')')!=string::npos)input.erase(input.find(')')-1,1);
					}
					cmd=input;
					ERROR_LEVEL=1;
				}
 			}else ERROR_LEVEL=-1;
			return ERROR_LEVEL;
		}
		void clear(){
			cmd="";
			value.clear();
			_switch.clear();
		}
};
class Var{
	public:
		vector<string>varname;
		vector<string>varvalue;
		string getvalue_num(int number){
			//��1Ϊ��ʼ����ֵ
			if(number<=varvalue.size())return varvalue[number-1];
			return ERROR;
		}
		int find(string name){
			if(varname.size()<1)return -1;
			for(int i=0;i<varname.size();++i){
				if(varname[i]==name)return i;
			}
			return -1;
		}
		string getvalue(string _varname){
			return find(_varname)!=-1?varvalue[find(_varname)]:"err";
		}
		int revalue(int varnum,string newvalue){
			//0Ϊ��������ֵ,-1��ʾ�Ƿ�����ֵ
			if(varnum<=varvalue.size()){
				varvalue[varnum]=newvalue;
				return 0;
			}
			return -1;
		}
		void createvar(string name,string value){
			varname.push_back(name);
			varvalue.push_back(value);
			return;
		}
		string varreplace(string input){
			while(input.find('#')!=string::npos){
				int start=input.find('#')+1;
				int end=input.find('#',start);
				if(end==string::npos){
					return ERROR;
				}
				string placeholder=input.substr(start, end - start);
				string value=getvalue(placeholder);
				if(value.c_str()==ERROR){
					return ERROR;
				}
				input.replace(start-1,end-start+2,value);
			}
			return input;
		}
};
class File{
	public:
		vector<string>helpfile;
		vector<string>configfile;
		vector<string>userfile;
		int LoadHelpFile(){
			ifstream f;
			string nr;
			f.open("Help\\MAINHELP.TXT",ios::in);
			if(f.is_open()==false)return -1;
			while(getline(f,nr)){
				helpfile.push_back(nr);
			}
			f.close();
			return 0;
		}
		int LoadConfigFile(){
			ifstream f;
			string nr;
			f.open("CONFIG",ios::in);
			if(f.is_open()==false)return -1;
			while(getline(f,nr)){
				configfile.push_back(nr);
			}
			f.close();
			return 0;
		}
		int LoadUserFile(const char *path,bool trim=false){
			ifstream f;
			string nr;
			f.open(path,ios::in);
			if(f.is_open()==false)return -1;
			while(getline(f,nr)){
				if(trim==true)while(nr[0]=='\t'||nr[0]==' ')nr.erase(0,1);
				userfile.push_back(nr);
			}
			f.close();
			return 0;
		}
		int clear(int check){
			//0=clear all,1=clear help&config,2=clear user
			if(check==0){
				helpfile.clear();
				userfile.clear();
				configfile.clear();
			}else if(check==1){
				helpfile.clear();
				configfile.clear();
			}else if(check==2){
				userfile.clear();
			}else return -1;
			return 0;
		}
};
class Exp{
	public:
		string getexp(string exp){
			if(exp.find('=')!=string::npos){
				if(exp.substr(0,exp.find('='))==exp.substr(exp.find('=')+1,exp.size()-exp.find('=')))return "TRUE";
				else return "FALSE";
			}
			if(exp.find('>')!=string::npos){
				if(exp.substr(0,exp.find('>'))>exp.substr(exp.find('>')+1,exp.size()-exp.find('>')))return "TRUE";
				else return "FALSE";
			}
			if(exp.find('<')!=string::npos){
				if(exp.substr(0,exp.find('<'))<exp.substr(exp.find('<')+1,exp.size()-exp.find('<')))return "TRUE";
				else return "FALSE";
			}
			if(exp.find('��')!=string::npos){
				if(exp.substr(0,exp.find('��'))>=exp.substr(exp.find('��')+1,exp.size()-exp.find('��')))return "TRUE";
				else return "FALSE";
			}
			if(exp.find('��')!=string::npos){
				if(exp.substr(0,exp.find('��'))<=exp.substr(exp.find('��')+1,exp.size()-exp.find('��')))return "TRUE";
				else return "FALSE";
			}
			if(exp=="CRLF"||exp=="crlf")return "\n";
			int first,second,out;
			if(exp.find('+')!=string::npos){
				first=atoi(exp.substr(0,exp.find('+')).c_str());
				exp.erase(0,exp.find('+'));
			}
			else if(exp.find('-')!=string::npos){
				first=atoi(exp.substr(0,exp.find('-')).c_str());
				exp.erase(0,exp.find('-'));
			}
			else if(exp.find('*')!=string::npos){
				first=atoi(exp.substr(0,exp.find('*')).c_str());
				exp.erase(0,exp.find('*'));
			}
			else if(exp.find('/')!=string::npos){
				first=atoi(exp.substr(0,exp.find('/')).c_str());
				exp.erase(0,exp.find('+'));
			}else return exp;
			if(exp[0]=='+')out=first+atoi(exp.substr(1,exp.size()-1).c_str());
			else if(exp[0]=='-')out=first-atoi(exp.substr(1,exp.size()-1).c_str());
			else if(exp[0]=='*')out=first*atoi(exp.substr(1,exp.size()-1).c_str());
			else if(exp[0]=='/')out=first/atoi(exp.substr(1,exp.size()-1).c_str());
			return int2string(out);
		}
		string expreplace(string input){
			while(input.find('$')!=string::npos){
				int start=input.find('$')+1;
				int end=input.find('$',start);
				if(end==string::npos){
					return "err";
				}
				string placeholder=input.substr(start,end-start);
				string value=getexp(placeholder);
				if(value.c_str()=="err"){
					return "err";
				}
				input.replace(start-1,end-start+2,value);
			}
			return input;
		}
};
#endif