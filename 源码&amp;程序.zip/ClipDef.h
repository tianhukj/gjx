#ifndef CLIPDEF
#define CLIPDEF
#define HELP_CONFIG 0
#define USER 1
#define ALL 2
#define ERROR "err"
#define ifBASIC 0
#define ifELSE 1
#define ifELSEIF 2
#include<iostream>
#include<fstream>
#include<cstdlib>
#include<cmath>
#include<vector>
#include<string>
#include<cstring>
#include<ctime>
#include<cstdio>
#include<conio.h>
#include<windows.h>
#include<process.h>
using namespace std;
#endif