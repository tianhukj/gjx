bool IsFile=false,IsFunc=false;
int firstreplace=0;
int FileLines=0,FuncLines=0,funcsuoyin=0;
#include "ClipDef.h"
#include "ClipFunc.h"
#define _NONE 0
#define _ELSE 1
#define _ELSEIF 2
File userfile;
Func mainFuncPage;
vector<string>codepage;
UserInput in;
Cahce mainCahcePage;
Var mainvar;
Exp mainexp;
vector<string>cd_value;
vector<string>cd_switch;
string cd_cmd;
int for_cs(int cs);
int _if(int iftype);
bool is_exit=false;
void init(){
	system("color 0f");
}
File ReadScript;
void DoFunc(int suoyin,vector<string>&valuelist);
int makecodepage(bool func=false){
	string nr;
	while(true){
		if(IsFile==false&&IsFunc==false)getline(cin,nr);
		else{
			if(IsFile==true&&IsFunc==false){
				++FileLines;
				nr=ReadScript.userfile[FileLines-1];
			}else{
				++FuncLines;
				nr=mainFuncPage.funcMem[funcsuoyin][FuncLines-1];
			}
		}
		if(nr==(func==true?"do process":"do"))return 0;
		if(nr=="else"&&func==false)return ifELSE;
		if(nr=="else if"&&func==false)return ifELSEIF;
		codepage.push_back(nr);
	}
}
void OnError(int ErrorCode,const char *str){
	string ec=int2string(ErrorCode);
	if(ec.size()==1)ec="00"+ec;
	if(ec.size()==2)ec="0"+ec;
	ColorOut(4,0);
	cout<<"ERROR"<<ec<<':'<<str<<endl;
	ColorOut(15,0);
}
int codedoer(){
	if(cd_cmd=="var"){
		if(mainvar.find(cd_value[0])==-1){
			if(cd_value.size()<2)mainvar.createvar(cd_value[0],"Null");
			else mainvar.createvar(cd_value[0],cd_value[1]);
		}else mainvar.revalue(mainvar.find(cd_value[0]),cd_value[1]);
	}else if(cd_cmd=="exit"){
		is_exit=true;
		return cd_value.size()!=0?atoi(cd_value[0].c_str()):0;
	}else if(cd_cmd=="show"){
		for(int i=0;i<cd_value.size();++i)cout<<cd_value[i]<<"\n";
	}else if(cd_cmd=="showmsg")MessageBox(0,cd_value.size()>0?cd_value[0].c_str():"",cd_value.size()>1?cd_value[1].c_str():"",MB_OK);
	else if(cd_cmd=="pause"){
		if(cd_value.size()>0)cout<<cd_value[0];
		getch();
		cout<<'\n';
	}else if(cd_cmd=="clear")ClearConsole();
	else if(cd_cmd=="for"){
		if(cd_value.size()!=0){
			makecodepage();
			for_cs(atoi(cd_value[0].c_str()));
			codepage.clear();
		}
	}else if(cd_cmd=="if"){
		int type=makecodepage();
		mainCahcePage.putin(codepage);
		mainCahcePage.fCahce.push_back(cd_value[0]);
		if(type==ifBASIC)_if(type);
		else if(type==ifELSE){
			codepage.clear();
			type=makecodepage();
			if(type!=ifBASIC){
				OnError(1,"����Ĵ���ν�����");
				return -1;
			}
			mainCahcePage.putin(codepage);
			_if(ifELSE);
		}
		codepage.clear();
		mainCahcePage.fCahce.clear();
		mainCahcePage.dCahce.clear();
	}else if(cd_cmd=="killvar"){
		if(cd_switch[0]=="name"){
			if(mainvar.find(cd_value[0])!=-1){
				mainvar.varname.erase(mainvar.varname.begin()+mainvar.find(cd_value[0]));
				mainvar.varvalue.erase(mainvar.varvalue.begin()+mainvar.find(cd_value[0])+1);
			}
		}
		if(cd_switch[0]=="num"){
			if(atoi(cd_switch[0].c_str())<mainvar.varvalue.size())mainvar.varvalue.erase(mainvar.varvalue.begin()+atoi(cd_switch[0].c_str()));
			if(atoi(cd_switch[0].c_str())<mainvar.varname.size())mainvar.varname.erase(mainvar.varname.begin()+atoi(cd_switch[0].c_str()));
		}
	}else if(cd_cmd=="debug"){
		if(cd_switch[0]=="sv"){
			int maxmum=mainvar.varname.size()>=mainvar.varvalue.size()?mainvar.varname.size():mainvar.varvalue.size();
			for(int i=0;i<maxmum;++i)cout<<"name:"<<(mainvar.varname.size()>i?mainvar.varname[i].c_str():" ")<<';'<<"value:"<<(mainvar.varvalue.size()>i?mainvar.varvalue[i].c_str():" ")<<'\n';
		}
	}else if(cd_cmd=="process"){
		codepage.clear();
		int type=makecodepage(true);
		//if(type!=0){
		//	OnError(1,"����Ĵ���ν�����");
		//	return -1;
		//}
		mainFuncPage.createFunc(codepage,cd_value[0]);
		codepage.clear();
	}else if(cd_cmd=="call"){
		if(cd_switch[0]=="p"){
			if(mainFuncPage.find(cd_value[0])!=-1){
				string name=cd_value[0];
				if(cd_value.size()==1)cd_value.push_back("NULL");
				cd_value.erase(cd_value.begin()+0);
				DoFunc(mainFuncPage.find(name),cd_value);
			}else OnError(4,"δ����Ĺ���");
		}	
	}else if(cd_cmd=="file"){
		if(cd_switch.size()>0&&cd_switch[0]=="l"){
			userfile.clear(2);
			if(userfile.LoadUserFile(cd_value.size()>0?cd_value[0].c_str():"Null")==-1)OnError(2,"�Ƿ�·��");
		}else if(cd_switch.size()>0&&cd_switch[0]=="c")userfile.clear(2);
		else if(cd_switch.size()>0&&cd_switch[0]=="r"&&cd_value.size()>1){
			if(cd_value[0]!="size"){
				if(mainvar.find(cd_value[1])==-1){
					if(cd_value.size()<2||atoi(cd_value[0].c_str())>userfile.userfile.size())mainvar.createvar(cd_value[1],"Null");
					else mainvar.createvar(cd_value[1],userfile.userfile[atoi(cd_value[0].c_str())-1]);
				}else{
					if(cd_value.size()<2||atoi(cd_value[0].c_str())>userfile.userfile.size())mainvar.revalue(mainvar.find(cd_value[1]),"Null");
					else mainvar.revalue(mainvar.find(cd_value[1]),userfile.userfile[atoi(cd_value[0].c_str())-1]);
				}
			}else{
				if(mainvar.find(cd_value[1])!=-1)mainvar.revalue(mainvar.find(cd_value[1]),int2string(userfile.userfile.size()));
				else mainvar.createvar(cd_value[1],int2string(userfile.userfile.size()));
			}
		}
	}else if(cd_cmd=="firstreplace"){
		if(cd_value.size()>0){
			if(cd_value[0]=="var")firstreplace=0;
			else if(cd_value[0]=="exp")firstreplace=1;
			else OnError(3,"�Ƿ�����ֵ");
		}
	}else if(cd_cmd=="getinput"){
		string tmp;
		if(cd_value.size()>1)cout<<cd_value[1];
		getline(cin,tmp);
		if(cd_value.size()>0){
			if(mainvar.find(cd_value[0])!=-1)mainvar.revalue(mainvar.find(cd_value[0]),tmp);
			else mainvar.createvar(cd_value[0],tmp);
		}
	}else if(cd_cmd=="cmd"){
		if(cd_value.size()>0)system(cd_value[0].c_str());
	}else if(cd_cmd!=""){
		string ErrorStr="�Ƿ�ָ�� \""+cd_cmd+"\"";
		OnError(0,ErrorStr.c_str());
	}
	return 0;
}
void DoFunc(int suoyin,vector<string>&valuelist){
	IsFunc=true;
	funcsuoyin=suoyin;
	vector<string>valuenamelist;
	string funcinput_raw;
	UserInput funcin;
	int error_level_return;
	for(int i=0;i<valuelist.size();++i){
		if(mainvar.find("%"+int2string(i+1))!=-1)mainvar.revalue(mainvar.find("%"+int2string(i+1)),valuelist[i]);
		else mainvar.createvar("%"+int2string(i+1),valuelist.size()>=i+1?valuelist[i]:"NULL");
		valuenamelist.push_back("%"+int2string(i+1));
	}
	//cout<<mainFuncPage.funcMem[suoyin].size()<<endl;
	//for(int j=0;j<mainFuncPage.funcMem[suoyin].size();++j){
	while(true){
		++FuncLines;
		if(FuncLines>mainFuncPage.funcMem[suoyin].size())break;
		//if(j>=mainFuncPage.funcMem[suoyin].size())break;
		//cout<<j<<endl;
		cin.clear();
		cin.sync();
		funcinput_raw=mainFuncPage.funcMem[suoyin][FuncLines-1];

		if(firstreplace==0){
			funcinput_raw=mainvar.varreplace(funcinput_raw);
			funcinput_raw=mainexp.expreplace(funcinput_raw);
		}else if(firstreplace==1){
			funcinput_raw=mainexp.expreplace(funcinput_raw);
			funcinput_raw=mainvar.varreplace(funcinput_raw);
		}
		
		funcinput_raw=mainFuncPage.func_valuereplace(funcinput_raw,valuelist);
		error_level_return=funcin.cut(funcinput_raw);
		funcinput_raw="";
		//������ʹ�ý�ȡ���ָ��Ƭ��,���ҽ��н�һ������
		cd_value.clear();
		cd_switch.clear();
		cd_cmd="";
		cd_value.swap(funcin.value);
		cd_switch.swap(funcin._switch);
		cd_cmd=funcin.cmd;
		error_level_return=codedoer();
		error_level_return=0;
		funcin.clear();
	}
	for(int k=0;k<valuenamelist.size();++k){
		mainvar.varname.erase(mainvar.varname.begin()+mainvar.find(valuenamelist[k]));
		mainvar.varvalue.erase(mainvar.varvalue.begin()+mainvar.find(valuenamelist[k])+1);
	}
	IsFunc=false;
	FuncLines=0;
}
int _if(int iftype){
	//ʹ��fCahce�е�Ԫ����Ϊ����ʽ,dCahce�е�vector��Ϊ�����
	if(iftype==ifBASIC){
		if(mainCahcePage.fCahce[0]=="TRUE"){
			string ifinput_raw;
			UserInput ifin;
			int error_level_return;
			for(int j=0;j<mainCahcePage.dCahce[0].size();++j){
				cin.clear();
				cin.sync();
				ifinput_raw=mainCahcePage.dCahce[0][j];
				
				if(firstreplace==0){
					ifinput_raw=mainvar.varreplace(ifinput_raw);
					ifinput_raw=mainexp.expreplace(ifinput_raw);
				}else if(firstreplace==1){
					ifinput_raw=mainexp.expreplace(ifinput_raw);
					ifinput_raw=mainvar.varreplace(ifinput_raw);
				}
				
				error_level_return=ifin.cut(ifinput_raw);
				ifinput_raw="";
				//������ʹ�ý�ȡ���ָ��Ƭ��,���ҽ��н�һ������
				cd_value.clear();
				cd_switch.clear();
				cd_cmd="";
				cd_value.swap(ifin.value);
				cd_switch.swap(ifin._switch);
				cd_cmd=ifin.cmd;
				error_level_return=codedoer();
				if(is_exit==true)return error_level_return;
				error_level_return=0;
				ifin.clear();
			}
		}
	}else if(iftype==ifELSE){
		if(mainCahcePage.fCahce[0]=="TRUE"){
			string ifinput_raw;
			UserInput ifin;
			int error_level_return;
			for(int j=0;j<mainCahcePage.dCahce[0].size();++j){
				cin.clear();
				cin.sync();
				ifinput_raw=mainCahcePage.dCahce[0][j];

				if(firstreplace==0){
					ifinput_raw=mainvar.varreplace(ifinput_raw);
					ifinput_raw=mainexp.expreplace(ifinput_raw);
				}else if(firstreplace==1){
					ifinput_raw=mainexp.expreplace(ifinput_raw);
					ifinput_raw=mainvar.varreplace(ifinput_raw);
				}

				error_level_return=ifin.cut(ifinput_raw);
				ifinput_raw="";
				//������ʹ�ý�ȡ���ָ��Ƭ��,���ҽ��н�һ������
				cd_value.clear();
				cd_switch.clear();
				cd_cmd="";
				cd_value.swap(ifin.value);
				cd_switch.swap(ifin._switch);
				cd_cmd=ifin.cmd;
				error_level_return=codedoer();
				if(is_exit==true)return error_level_return;
				error_level_return=0;
				ifin.clear();
			}
		}else{
			string ifinput_raw;
			UserInput ifin;
			int error_level_return;
			for(int j=0;j<mainCahcePage.dCahce[1].size();++j){
				cin.clear();
				cin.sync();
				ifinput_raw=mainCahcePage.dCahce[1][j];

				if(firstreplace==0){
					ifinput_raw=mainvar.varreplace(ifinput_raw);
					ifinput_raw=mainexp.expreplace(ifinput_raw);
				}else if(firstreplace==1){
					ifinput_raw=mainexp.expreplace(ifinput_raw);
					ifinput_raw=mainvar.varreplace(ifinput_raw);
				}

				error_level_return=ifin.cut(ifinput_raw);
				ifinput_raw="";
				//������ʹ�ý�ȡ���ָ��Ƭ��,���ҽ��н�һ������
				cd_value.clear();
				cd_switch.clear();
				cd_cmd="";
				cd_value.swap(ifin.value);
				cd_switch.swap(ifin._switch);
				cd_cmd=ifin.cmd;
				error_level_return=codedoer();
				if(is_exit==true)return error_level_return;
				error_level_return=0;
				ifin.clear();
			}
		}
	}
}
int for_cs(int cs){
	string forinput_raw;
	UserInput forin;
	int error_level_return;
	for(int i=0;i<cs;++i){
		for(int j=0;j<codepage.size();++j){
			cin.clear();
			cin.sync();
			forinput_raw=codepage[j];

			if(firstreplace==0){
				forinput_raw=mainvar.varreplace(forinput_raw);
				forinput_raw=mainexp.expreplace(forinput_raw);
			}else if(firstreplace==1){
				forinput_raw=mainexp.expreplace(forinput_raw);
				forinput_raw=mainvar.varreplace(forinput_raw);
			}

			error_level_return=forin.cut(forinput_raw);
			forinput_raw="";
			//������ʹ�ý�ȡ���ָ��Ƭ��,���ҽ��н�һ������
			cd_value.clear();
			cd_switch.clear();
			cd_cmd="";
			cd_value.swap(forin.value);
			cd_switch.swap(forin._switch);
			cd_cmd=forin.cmd;
			error_level_return=codedoer();
			if(is_exit==true)return error_level_return;
			error_level_return=0;
			forin.clear();
		}
	}
	return 0;
}
int main(int argc,char *argv[]){
	init();
	if(argc<2){
		//������
		string userinput_raw;
		int error_level_return;
		while(true){
			cin.clear();
			cin.sync();
			getline(cin,userinput_raw);

			if(firstreplace==0){
				userinput_raw=mainvar.varreplace(userinput_raw);
				userinput_raw=mainexp.expreplace(userinput_raw);
			}else if(firstreplace==1){
				userinput_raw=mainexp.expreplace(userinput_raw);
				userinput_raw=mainvar.varreplace(userinput_raw);
			}

			error_level_return=in.cut(userinput_raw);
			userinput_raw="";
			//������ʹ�ý�ȡ���ָ��Ƭ��,���ҽ��н�һ������
			cd_value.clear();
			cd_switch.clear();
			cd_cmd="";
			cd_value.swap(in.value);
			cd_switch.swap(in._switch);
			cd_cmd=in.cmd;
			error_level_return=codedoer();
			if(is_exit==true)return error_level_return;
			error_level_return=0;
			in.clear();
		}
	}else{
		//�������
		IsFile=true;
		ReadScript.LoadUserFile(argv[1],true);
		string userinput_raw;
		int error_level_return;
		while(true){
			++FileLines;
			if(FileLines>ReadScript.userfile.size())return 0;
			userinput_raw=ReadScript.userfile[FileLines-1];

			if(firstreplace==0){
				userinput_raw=mainvar.varreplace(userinput_raw);
				userinput_raw=mainexp.expreplace(userinput_raw);
			}else if(firstreplace==1){
				userinput_raw=mainexp.expreplace(userinput_raw);
				userinput_raw=mainvar.varreplace(userinput_raw);
			}

			error_level_return=in.cut(userinput_raw);
			userinput_raw="";
			//������ʹ�ý�ȡ���ָ��Ƭ��,���ҽ��н�һ������
			cd_value.clear();
			cd_switch.clear();
			cd_cmd="";
			cd_value.swap(in.value);
			cd_switch.swap(in._switch);
			cd_cmd=in.cmd;
			error_level_return=codedoer();
			if(is_exit==true)return error_level_return;
			error_level_return=0;
			in.clear();
		}
	}
	return 0;
}
