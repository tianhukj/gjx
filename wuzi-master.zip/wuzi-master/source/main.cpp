// Wuzi chess game 
// program by ET-16G, Apr. 5 2024

#include "..\include\wuzi.h"

int main(void)
{
    Wuzi wuzi = Wuzi();
    wuzi.exec();

    return 0;
}
