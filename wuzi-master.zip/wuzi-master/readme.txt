使用 mingw64 在 Windows 环境中编译。
