// Wuzi chess game 
// program by ET-16G, Apr. 5 2024

#pragma once
#define BUILD_NUMBER        50
