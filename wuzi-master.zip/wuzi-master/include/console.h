// Wuzi chess game 
// program by ET-16G, Apr. 5 2024
// Follwing code comes from Ghdgtdgu

#pragma once
#include "coord.h"

void gotoXY(Coord sCoord);
void printf_ex(Coord sCoord, int color, const char *str, ...);
void putchar_ex(Coord sCoord, int color, const char c);
